
d3.json("/albums.json").then(function(data) {

  document.getElementById("Selecter").addEventListener("change", function() {
    let selectedGenre = this.value;
  
    let filteredData = data.filter(function(album) {
      return album.genre === selectedGenre;
    });
    updateAlbumList(filteredData);
  });
});

function updateAlbumList(albums) {
  let albumList = d3.select("#albumList");
  albumList.html(''); 
  
  albums.forEach(function(album) {
    albumList.append("li")
      .text(album.artistName + " - " + album.albumName + " - " + album.trackList.length)
  });
}

  
 