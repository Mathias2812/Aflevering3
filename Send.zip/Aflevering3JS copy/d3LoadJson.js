
d3.json("/albums.json").then(function(data) {

  console.log(data);

  d3.select("#JSON").append("h2").text("JSON Data:");

  document.getElementById("Selecter").addEventListener("SelecterEvent", myFunction);
   function myFunction(data){
  if (Selecter.value = "Rock")
   return data.genre = "Rock"
  else if (Selecter.value = "Punk")
  return data.genre =  "Rock"
  else if (Selecter.value = "Soundtrack")
  return data.genre = "Soundtrack"
  else if (Selecter.value = "Pop")
  return data.genre = "Pop"
}

  d3.select("#JSON")  
    .selectAll("p")
    .data(data)
    .enter()
    .append("p")
    .text(function (album) {
      return (
        album.artistName +
        " - " +
        album.albumName +
        " - " +
        album.genre +
        " - " +
        album.trackList.length +
        " - "
       
      );
    
    });
  }
);

