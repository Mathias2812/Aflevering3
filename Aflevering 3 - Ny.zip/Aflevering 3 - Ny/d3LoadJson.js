
d3.json("/albums.json").then(function(data) {

  console.log(data);

  d3.select("#JSON").append("h2").text("JSON Data:");


  document.getElementById("Selecter").addEventListener("change", function() {
    let selectedGenre = this.value;
  
    let filteredData = data.filter(function(album) {
      return album.genre === selectedGenre;
    });
    updateAlbumList(filteredData);
  });
});

function updateAlbumList(albums) {
  let albumList = d3.select("#albumList");
  albumList.html(''); 
  
  albums.forEach(function(album) {
    albumList.append("li")
      .text(album.artistName + " - " + album.albumName);
  });
}

  
  d3.select("#JSON")  
    .selectAll("p")
    .data(data)
    .enter()
    .append("p")
    .text(function (album) {
      return (
        album.artistName +
        " - " +
        album.albumName +
        " - " +
        album.genre +
        " - " +
        album.trackList.length +
        " - "
       
      );
    
    });
  
;

